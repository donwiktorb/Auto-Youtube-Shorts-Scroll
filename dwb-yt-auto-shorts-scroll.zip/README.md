# Auto-Youtube-Shorts-Scroll
Auto scrolls youtube shorts on the end of current
It's extension for firefox
https://addons.mozilla.org/pl/firefox/addon/yt_shorts_auto_scroll/
^ public once checked and listed